-- jack tercheria
-- 2/5/2024
-- dba221

INSERT INTO customer (CustID, Name, ShipCity, Discount)
VALUES
(133568, 'Smith Mfg.', 'Portland', .050),
(246900, 'Bolt Co.', 'Eugene', .020),
(275978, 'Ajax Inc.', 'Albany', NULL),
(499320, 'Adapto', 'Portland', .000),
(499921, 'Bill Bldg.', 'Eugene', .100),
(518980, 'Floradel', 'Seattle', .000),
(663456, 'Alpine Inc.', 'Seattle', .010),
(681065, 'Telez Co.', 'Albany', .000),
(687309, 'Nautilus', 'Portland', .050),
(781010, 'Udapto Mfg.', 'Seattle', .000),
(888402, 'Seaworthy', 'Albany', .010),
(890003, 'AA Products', 'Portland', .010),
(905011, 'Wood Bros.', 'Eugene', .010);
