SELECT * 
FROM customer
WHERE ShipCity = 'Seattle';