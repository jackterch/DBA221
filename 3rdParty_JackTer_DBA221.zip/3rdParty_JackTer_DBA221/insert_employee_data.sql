-- jack tercheria 
-- 2/5/2025
-- dba221

INSERT INTO Employee (EmpID, FstNam, MdlInl, LstNam, MgrEmpID )
VALUES
(104681, 'Barb', 'L', 'Gibbens', 898613),
(227504, 'Greg', 'J', 'Zimmerman', 668466),
(668446, 'Dave', 'R', 'Bernard', 709453),
(898613, 'Trish', 'S', 'Faubion', 668466),
(899001, 'Rick', 'D', 'Castor', 898613);