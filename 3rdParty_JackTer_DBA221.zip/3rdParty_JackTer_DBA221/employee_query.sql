SELECT *
FROM Employee
WHERE FstNam = 'Barb';